export interface Mp4InspectResult {
  isIsoBmff: boolean;
  width: number;
  height: number;
  rotation: number;
  durationSec: number;
  avgFps: number;
  fpsNum: number;
  fpsDen: number;
  videoBitrateBps: number;
  hasAudio: boolean;
  hdrMode: 'sdr' | 'hlg' | 'pq';
  colorPrimaries: number;
  colorTrc: number;
  colorSpace: number;
  colorRange: number;
  amveBytes: Uint8Array | null;
}

export interface PatchReport {
  engine: string;
  version: string;
  width: number;
  height: number;
  fps: number;
  hdr: 'sdr' | 'hlg' | 'pq';
  hadAudio: boolean;
  tracks: number;
  durationMs: number;
}

export interface ProcessResult {
  bytes: Uint8Array;
  report: PatchReport;
}

export interface CompatibilityResult {
  compatible: boolean;
  reason: string;
}

export interface HidzzMp4PatcherApi {
  version: string;
  engine: string;
  processAndReport: (input: Uint8Array | ArrayBuffer) => ProcessResult;
  inspect: (input: Uint8Array | ArrayBuffer) => Mp4InspectResult;
  checkCompatibility: (input: Uint8Array | ArrayBuffer) => CompatibilityResult;
  verifyOutput: (input: Uint8Array | ArrayBuffer) => {
    ok: boolean;
    reason?: string;
    tracks?: number;
    durationMs?: number;
    totalBytes?: number;
  };
}

declare global {
  interface Window {
    HidzzMp4Patcher?: HidzzMp4PatcherApi;
  }
}

let loaderPromise: Promise<HidzzMp4PatcherApi> | null = null;

export function ensurePatcherLoaded(): Promise<HidzzMp4PatcherApi> {
  if (typeof window !== 'undefined' && window.HidzzMp4Patcher) {
    return Promise.resolve(window.HidzzMp4Patcher);
  }
  if (loaderPromise) return loaderPromise;

  loaderPromise = new Promise((resolve, reject) => {
    const existing = document.querySelector<HTMLScriptElement>(
      'script[src*="patcher_2a70437b.js"]'
    );
    if (existing && window.HidzzMp4Patcher) {
      resolve(window.HidzzMp4Patcher);
      return;
    }

    const script = document.createElement('script');
    script.src = '/assets/aistudio/patcher_2a70437b.js';
    script.async = true;
    script.onload = () => {
      if (window.HidzzMp4Patcher) {
        resolve(window.HidzzMp4Patcher);
      } else {
        reject(new Error('Patcher script loaded without initializing HidzzMp4Patcher.'));
      }
    };
    script.onerror = () => {
      loaderPromise = null;
      reject(new Error('Failed to load patcher_2a70437b.js.'));
    };
    document.head.appendChild(script);
  });

  return loaderPromise;
}

export function formatBytes(bytes: number): string {
  if (!Number.isFinite(bytes) || bytes <= 0) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB'];
  const exp = Math.min(units.length - 1, Math.floor(Math.log(bytes) / Math.log(1024)));
  const val = bytes / 1024 ** exp;
  return `${val >= 100 || exp === 0 ? val.toFixed(0) : val.toFixed(1)} ${units[exp]}`;
}

export function formatDuration(seconds: number): string {
  if (!Number.isFinite(seconds) || seconds <= 0) return '0:00';
  const total = Math.round(seconds);
  const m = Math.floor(total / 60);
  const s = total % 60;
  return `${m}:${String(s).padStart(2, '0')}`;
}

export function formatBitrate(bps: number): string {
  if (!Number.isFinite(bps) || bps <= 0) return '—';
  const mbps = bps / 1_000_000;
  return mbps >= 1 ? `${mbps.toFixed(1)} Mbps` : `${Math.round(bps / 1000)} kbps`;
}

export function buildPatchedFileName(originalName: string): string {
  const base = originalName.replace(/\.(mp4|mov|m4v)$/i, '');
  return `${base}_zero_patched.mp4`;
}
