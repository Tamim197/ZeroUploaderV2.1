export type Lang = 'en' | 'id';

export interface CopyBundle {
  title: string;
  subtitlePrefix: string;
  subtitleHighlight: string;
  subtitleSuffix: string;
  menuLabel: string;
  selectVideo: string;
  changeVideo: string;
  patchAndSave: string;
  patching: string;
  openInNewTab: string;
  previewVideo: string;
  followLabel: string;
  tiktokLabel: string;
  tiktokHandle: string;
  telegramLabel: string;
  telegramHandle: string;
  tutorialLabel: string;
  tutorialButton: string;
  footerText: string;
  noFileHint: string;
  compatibleLabel: string;
  incompatibleLabel: string;
  patchedReadyLabel: string;
  tracksLabel: string;
  audioPresent: string;
  audioAdded: string;
  clearFile: string;
  dropHint: string;
  tutorialModal: {
    title: string;
    subtitle: string;
    close: string;
    stepsTitle: string;
    steps: { title: string; desc: string }[];
    specsTitle: string;
    specs: string[];
  };
  previewModal: {
    title: string;
    close: string;
    download: string;
  };
}

export const COPY: Record<Lang, CopyBundle> = {
  en: {
    title: 'ZERO UPLOADER',
    subtitlePrefix: 'This is an ',
    subtitleHighlight: 'Website',
    subtitleSuffix: ' to prevent your TikTok videos from being compressed',
    menuLabel: 'MENU',
    selectVideo: 'SELECT VIDEO',
    changeVideo: 'CHANGE VIDEO',
    patchAndSave: 'PATCH AND SAVE',
    patching: 'PATCHING...',
    openInNewTab: 'OPEN IN NEW TAB',
    previewVideo: 'PREVIEW',
    followLabel: 'FOLLOW / COMMUNITY',
    tiktokLabel: 'TikTok',
    tiktokHandle: '@zero.sparky',
    telegramLabel: 'Telegram',
    telegramHandle: '@zero_sparky',
    tutorialLabel: 'TUTORIAL',
    tutorialButton: 'Upload Method Tutorial',
    footerText: 'ZERO UPLOADER FOR TIKTOK',
    noFileHint: 'Select an MP4 or MOV video first before patching or opening.',
    compatibleLabel: 'MP4 Ready',
    incompatibleLabel: 'Unsupported Container',
    patchedReadyLabel: 'Patched & Saved',
    tracksLabel: 'tracks',
    audioPresent: 'Audio OK',
    audioAdded: 'Silent Audio Added',
    clearFile: 'Remove selected video',
    dropHint: 'Drop MP4 / MOV here',
    tutorialModal: {
      title: 'Upload Method Tutorial',
      subtitle: 'How to patch your video with ZERO Method before uploading to TikTok.',
      close: 'Close',
      stepsTitle: 'Step-by-Step Guide',
      steps: [
        {
          title: '1. Export clean H.264 video',
          desc: 'Export your edit as a standard .mp4 or .mov file (1080p, 60fps, ~8–15 Mbps recommended for sharp playback).'
        },
        {
          title: '2. Select your video file',
          desc: 'Tap the SELECT VIDEO banner above and choose the video from your phone gallery, Files, or desktop.'
        },
        {
          title: '3. Tap Patch and Save',
          desc: 'The container patcher runs 100% locally in your browser—rebuilding the moov/mdat atoms, preserving AMVE/HDR color tags, and appending the dual-stsd audio structure.'
        },
        {
          title: '4. Upload the patched MP4',
          desc: 'Upload the downloaded _zero_patched.mp4 file directly to TikTok (or tap Open in New Tab to save/share on mobile).'
        }
      ],
      specsTitle: 'Compatibility Notes',
      specs: [
        'Supports standard non-fragmented MP4 / MOV files up to 4 GB.',
        'All processing happens locally on your device—no video is uploaded to external servers.',
        'If your video has no audio track, a compliant silent AAC tail is automatically synthesized.'
      ]
    },
    previewModal: {
      title: 'Patched Video Preview',
      close: 'Close',
      download: 'Download MP4'
    }
  },
  id: {
    title: 'ZERO UPLOADER',
    subtitlePrefix: 'Ini adalah ',
    subtitleHighlight: 'Website',
    subtitleSuffix: ' untuk mencegah video TikTok kamu terkompresi',
    menuLabel: 'MENU',
    selectVideo: 'PILIH VIDEO',
    changeVideo: 'GANTI VIDEO',
    patchAndSave: 'PATCH & SIMPAN',
    patching: 'MEMPROSES...',
    openInNewTab: 'BUKA DI TAB BARU',
    previewVideo: 'PRATINJAU',
    followLabel: 'IKUTI / KOMUNITAS',
    tiktokLabel: 'TikTok',
    tiktokHandle: '@zero.sparky',
    telegramLabel: 'Telegram',
    telegramHandle: '@zero_sparky',
    tutorialLabel: 'TUTORIAL',
    tutorialButton: 'Tutorial Metode Upload',
    footerText: 'ZERO UPLOADER FOR TIKTOK',
    noFileHint: 'Pilih file video MP4 atau MOV terlebih dahulu sebelum memproses.',
    compatibleLabel: 'MP4 Siap',
    incompatibleLabel: 'Format Tidak Didukung',
    patchedReadyLabel: 'Berhasil Di-patch',
    tracksLabel: 'track',
    audioPresent: 'Audio OK',
    audioAdded: 'Audio Hening Ditambahkan',
    clearFile: 'Hapus video terpilih',
    dropHint: 'Lepaskan MP4 / MOV di sini',
    tutorialModal: {
      title: 'Tutorial Metode Upload',
      subtitle: 'Cara mem-patch video dengan ZERO Method sebelum upload ke TikTok.',
      close: 'Tutup',
      stepsTitle: 'Panduan Langkah Demi Langkah',
      steps: [
        {
          title: '1. Export video H.264 bersih',
          desc: 'Export hasil edit sebagai file .mp4 atau .mov standar (disarankan 1080p, 60fps, ~8–15 Mbps agar tetap tajam).'
        },
        {
          title: '2. Pilih file video kamu',
          desc: 'Ketuk banner PILIH VIDEO di atas lalu pilih video dari galeri HP, File, atau komputer.'
        },
        {
          title: '3. Ketuk Patch & Simpan',
          desc: 'Patcher berjalan 100% lokal di browser—menyusun ulang atom moov/mdat, menjaga metadata AMVE/HDR, serta menyisipkan struktur audio dual-stsd.'
        },
        {
          title: '4. Upload file hasil patch',
          desc: 'Upload file _zero_patched.mp4 yang terunduh langsung ke TikTok (atau ketuk Buka di Tab Baru untuk simpan di HP).'
        }
      ],
      specsTitle: 'Catatan Kompatibilitas',
      specs: [
        'Mendukung file MP4 / MOV standar non-fragmented hingga 4 GB.',
        'Semua proses berjalan lokal di perangkatmu—video tidak dikirim ke server mana pun.',
        'Jika video belum memiliki audio, track AAC hening otomatis dibuatkan agar kompatibel.'
      ]
    },
    previewModal: {
      title: 'Pratinjau Video Patched',
      close: 'Tutup',
      download: 'Unduh MP4'
    }
  }
};
