import { useEffect } from 'react';
import { X, CheckCircle2 } from 'lucide-react';
import type { CopyBundle } from '../lib/i18n';

interface TutorialModalProps {
  open: boolean;
  onClose: () => void;
  copy: CopyBundle['tutorialModal'];
}

export function TutorialModal({ open, onClose, copy }: TutorialModalProps) {
  useEffect(() => {
    if (!open) return;
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/75 backdrop-blur-sm p-0 sm:p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="tutorial-modal-title"
      onClick={onClose}
    >
      <div
        className="w-full sm:max-w-[480px] max-h-[88dvh] overflow-y-auto rounded-t-3xl sm:rounded-2xl bg-[#13141a] border border-white/10 p-5 sm:p-6 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="w-10 h-1 bg-white/15 rounded-full mx-auto mb-4 sm:hidden" aria-hidden="true" />

        <div className="flex items-start justify-between gap-4 pb-4 border-b border-white/[0.07]">
          <div>
            <h2 id="tutorial-modal-title" className="text-base sm:text-lg font-bold text-white tracking-tight">
              {copy.title}
            </h2>
            <p className="mt-1 text-xs sm:text-sm text-[#8d909c] leading-relaxed">
              {copy.subtitle}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label={copy.close}
            className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl bg-[#1c1d25] hover:bg-[#252732] text-zinc-300 hover:text-white border border-white/[0.08] transition-colors shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-400"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="mt-5 space-y-4">
          <p className="text-[11px] font-semibold tracking-[0.14em] uppercase text-[#8d909c]">
            {copy.stepsTitle}
          </p>
          <div className="space-y-3">
            {copy.steps.map((step) => (
              <div
                key={step.title}
                className="rounded-xl bg-[#181920] border border-white/[0.07] p-3.5"
              >
                <h3 className="text-sm font-semibold text-white">{step.title}</h3>
                <p className="mt-1 text-xs sm:text-[13px] text-[#9a9da9] leading-relaxed">
                  {step.desc}
                </p>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-5 pt-4 border-t border-white/[0.07]">
          <p className="text-[11px] font-semibold tracking-[0.14em] uppercase text-[#8d909c] mb-2.5">
            {copy.specsTitle}
          </p>
          <ul className="space-y-2">
            {copy.specs.map((spec) => (
              <li key={spec} className="flex items-start gap-2.5 text-xs sm:text-[13px] text-[#a3a6b2]">
                <CheckCircle2 className="w-4 h-4 text-sky-400 shrink-0 mt-0.5" />
                <span>{spec}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="mt-6">
          <button
            type="button"
            onClick={onClose}
            className="w-full min-h-[46px] rounded-xl bg-[#1e2029] hover:bg-[#262934] border border-white/10 text-xs font-bold tracking-[0.06em] uppercase text-white transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-400"
          >
            {copy.close}
          </button>
        </div>
      </div>
    </div>
  );
}
