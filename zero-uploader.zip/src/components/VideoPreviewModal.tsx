import { useEffect } from 'react';
import { Download, X } from 'lucide-react';
import type { CopyBundle } from '../lib/i18n';

interface VideoPreviewModalProps {
  open: boolean;
  onClose: () => void;
  videoUrl: string | null;
  fileName: string;
  copy: CopyBundle['previewModal'];
}

export function VideoPreviewModal({
  open,
  onClose,
  videoUrl,
  fileName,
  copy
}: VideoPreviewModalProps) {
  useEffect(() => {
    if (!open) return;
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [open, onClose]);

  if (!open || !videoUrl) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/80 backdrop-blur-sm p-0 sm:p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="preview-modal-title"
      onClick={onClose}
    >
      <div
        className="w-full sm:max-w-[460px] rounded-t-3xl sm:rounded-2xl bg-[#13141a] border border-white/10 p-4 sm:p-5 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="w-10 h-1 bg-white/15 rounded-full mx-auto mb-3 sm:hidden" aria-hidden="true" />
        <div className="flex items-center justify-between gap-3 pb-3 border-b border-white/[0.07]">
          <div className="min-w-0">
            <h2 id="preview-modal-title" className="text-sm font-bold text-white truncate">
              {copy.title}
            </h2>
            <p className="text-[11px] text-[#8d909c] font-mono truncate mt-0.5">{fileName}</p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label={copy.close}
            className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl bg-[#1c1d25] hover:bg-[#252732] text-zinc-300 hover:text-white border border-white/[0.08] transition-colors shrink-0 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="mt-4 overflow-hidden rounded-xl bg-black border border-white/[0.08]">
          <video
            src={videoUrl}
            controls
            playsInline
            className="w-full max-h-[55dvh] object-contain mx-auto"
          />
        </div>

        <div className="mt-4 grid grid-cols-2 gap-2.5">
          <button
            type="button"
            onClick={onClose}
            className="min-h-[44px] rounded-xl bg-[#181920] hover:bg-[#22242e] border border-white/[0.08] text-xs font-bold uppercase tracking-wider text-zinc-200 cursor-pointer transition-colors"
          >
            {copy.close}
          </button>
          <a
            href={videoUrl}
            download={fileName}
            className="min-h-[44px] rounded-xl bg-[#222530] hover:bg-[#2b2f3d] border border-white/15 text-xs font-bold uppercase tracking-wider text-white flex items-center justify-center gap-2 transition-colors"
          >
            <Download className="w-4 h-4" />
            <span>{copy.download}</span>
          </a>
        </div>
      </div>
    </div>
  );
}
