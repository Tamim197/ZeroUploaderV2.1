import { useCallback, useEffect, useRef, useState, type ChangeEvent, type DragEvent } from 'react';
import {
  AlertCircle,
  CheckCircle2,
  Download,
  ExternalLink,
  FileVideo,
  Loader2,
  Play,
  X
} from 'lucide-react';
import { COPY, type Lang } from './lib/i18n';
import {
  buildPatchedFileName,
  ensurePatcherLoaded,
  formatBitrate,
  formatBytes,
  formatDuration,
  type CompatibilityResult,
  type Mp4InspectResult,
  type PatchReport
} from './lib/patcher';
import { TutorialModal } from './components/TutorialModal';
import { VideoPreviewModal } from './components/VideoPreviewModal';

import avatarImg from './assets/images/zero_avatar_1794583049544.jpg';
import bannerImg from './assets/images/bg.jpg';

const AVATAR_IMG = avatarImg;
const BANNER_IMG = bannerImg;

interface LoadedVideo {
  file: File;
  bytes: Uint8Array;
  inspect: Mp4InspectResult;
  compatibility: CompatibilityResult;
  sourceUrl: string;
}

interface PatchedVideo {
  fileName: string;
  bytes: Uint8Array;
  blobUrl: string;
  report: PatchReport;
}

function TikTokIcon({ className = 'w-5 h-5' }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="currentColor"
      aria-hidden="true"
      className={className}
    >
      <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-2.88 2.5 2.89 2.89 0 0 1-2.89-2.89 2.89 2.89 0 0 1 2.89-2.89c.28 0 .54.04.79.1v-3.5a6.37 6.37 0 0 0-.79-.05A6.34 6.34 0 0 0 3.15 15.2a6.34 6.34 0 0 0 6.34 6.34 6.34 6.34 0 0 0 6.34-6.34V8.7a8.16 8.16 0 0 0 4.76 1.52v-3.4a4.85 4.85 0 0 1-1-.13z" />
    </svg>
  );
}

function TelegramIcon({ className = 'w-5 h-5' }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      aria-hidden="true"
      className={className}
    >
      <path
        d="M21.426 3.556a1.18 1.18 0 0 0-1.228-.17L2.697 10.35a1.15 1.15 0 0 0 .08 2.163l4.38 1.497 1.694 5.367a.95.95 0 0 0 1.622.362l2.444-2.61 4.513 3.376a1.2 1.2 0 0 0 1.894-.716l2.927-14.95a1.18 1.18 0 0 0-.825-1.283ZM9.42 13.736l-.362 3.314-1.154-3.655 9.81-6.168-8.294 6.51Z"
        fill="#29A9EB"
      />
    </svg>
  );
}

export default function App() {
  const [lang, setLang] = useState<Lang>('en');
  const [avatarFailed, setAvatarFailed] = useState(false);
  const [bannerFailed, setBannerFailed] = useState(false);

  const [loadedVideo, setLoadedVideo] = useState<LoadedVideo | null>(null);
  const [patchedVideo, setPatchedVideo] = useState<PatchedVideo | null>(null);
  const [isReading, setIsReading] = useState(false);
  const [isPatching, setIsPatching] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [hintMsg, setHintMsg] = useState<string | null>(null);

  const [tutorialOpen, setTutorialOpen] = useState(false);
  const [previewOpen, setPreviewOpen] = useState(false);

  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const t = COPY[lang];

  // Clean up object URLs on unmount or replacement
  useEffect(() => {
    return () => {
      if (loadedVideo?.sourceUrl) URL.revokeObjectURL(loadedVideo.sourceUrl);
    };
  }, [loadedVideo?.sourceUrl]);

  useEffect(() => {
    return () => {
      if (patchedVideo?.blobUrl) URL.revokeObjectURL(patchedVideo.blobUrl);
    };
  }, [patchedVideo?.blobUrl]);

  // Pre-warm patcher script reference
  useEffect(() => {
    ensurePatcherLoaded().catch(() => {
      // Handled gracefully when user selects a file
    });
  }, []);

  const triggerDownload = useCallback((blobUrl: string, fileName: string) => {
    const a = document.createElement('a');
    a.href = blobUrl;
    a.download = fileName;
    a.rel = 'noopener';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  }, []);

  const openBlobInNewTab = useCallback((blobUrl: string) => {
    const a = document.createElement('a');
    a.href = blobUrl;
    a.target = '_blank';
    a.rel = 'noopener noreferrer';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  }, []);

  const handleFile = useCallback(async (file: File) => {
    setErrorMsg(null);
    setHintMsg(null);
    setPatchedVideo(null);
    setIsReading(true);

    try {
      const patcher = await ensurePatcherLoaded();
      const buffer = await file.arrayBuffer();
      const bytes = new Uint8Array(buffer);
      const compatibility = patcher.checkCompatibility(bytes);
      const inspect = patcher.inspect(bytes);
      const sourceUrl = URL.createObjectURL(file);

      setLoadedVideo({
        file,
        bytes,
        inspect,
        compatibility,
        sourceUrl
      });

      if (!compatibility.compatible) {
        setErrorMsg(compatibility.reason || t.incompatibleLabel);
      }
    } catch (err) {
      setLoadedVideo(null);
      setErrorMsg(err instanceof Error ? err.message : 'Unable to read video file.');
    } finally {
      setIsReading(false);
    }
  }, [t.incompatibleLabel]);

  const onFileInputChange = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      void handleFile(file);
    }
    e.target.value = '';
  };

  const onDrop = (e: DragEvent<HTMLButtonElement>) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      void handleFile(file);
    }
  };

  const clearSelectedFile = () => {
    setLoadedVideo(null);
    setPatchedVideo(null);
    setErrorMsg(null);
    setHintMsg(null);
  };

  const handlePatchAndSave = async () => {
    setHintMsg(null);
    setErrorMsg(null);

    if (!loadedVideo) {
      setHintMsg(t.noFileHint);
      fileInputRef.current?.click();
      return;
    }

    if (!loadedVideo.compatibility.compatible) {
      setErrorMsg(loadedVideo.compatibility.reason || t.incompatibleLabel);
      return;
    }

    // If already patched for this exact file, re-trigger download immediately
    if (patchedVideo) {
      triggerDownload(patchedVideo.blobUrl, patchedVideo.fileName);
      return;
    }

    setIsPatching(true);
    try {
      const patcher = await ensurePatcherLoaded();
      // Yield a frame so the UI updates to "PATCHING..." before synchronous MP4 byte rebuild
      await new Promise<void>((resolve) => requestAnimationFrame(() => resolve()));

      const result = patcher.processAndReport(loadedVideo.bytes);
      const blob = new Blob([result.bytes.buffer as ArrayBuffer], { type: 'video/mp4' });
      const blobUrl = URL.createObjectURL(blob);
      const outFileName = buildPatchedFileName(loadedVideo.file.name);

      setPatchedVideo({
        fileName: outFileName,
        bytes: result.bytes,
        blobUrl,
        report: result.report
      });

      triggerDownload(blobUrl, outFileName);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Failed to patch MP4 container.');
    } finally {
      setIsPatching(false);
    }
  };

  const handleOpenInNewTab = () => {
    setHintMsg(null);
    const targetUrl = patchedVideo?.blobUrl || loadedVideo?.sourceUrl;
    if (!targetUrl) {
      setHintMsg(t.noFileHint);
      fileInputRef.current?.click();
      return;
    }
    openBlobInNewTab(targetUrl);
  };

  const activePreviewUrl = patchedVideo?.blobUrl || loadedVideo?.sourceUrl || null;
  const activePreviewName =
    patchedVideo?.fileName || loadedVideo?.file.name || 'video_patched.mp4';

  return (
    <div className="zero-ambient-bg min-h-dvh w-full flex flex-col items-center justify-center px-3 py-5 sm:px-6 sm:py-10">
      <main className="w-full max-w-[540px] rounded-[22px] sm:rounded-[26px] bg-[#121318]/92 border border-white/[0.08] p-4 sm:p-6 shadow-[0_24px_64px_rgba(0,0,0,0.62)] backdrop-blur-md">
        {/* Header */}
        <header className="flex items-start sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3 sm:gap-3.5 min-w-0 flex-1">
            <div className="w-11 h-11 sm:w-12 sm:h-12 rounded-full overflow-hidden shrink-0 bg-[#1a1c24] ring-1 ring-white/15 flex items-center justify-center">
              {!avatarFailed ? (
                <img
                  src={AVATAR_IMG}
                  alt="ZERO Uploader avatar"
                  referrerPolicy="no-referrer"
                  onError={() => setAvatarFailed(true)}
                  className="w-full h-full object-cover"
                />
              ) : (
                <span className="text-sm font-extrabold text-sky-300">Z</span>
              )}
            </div>

            <div className="min-w-0 flex-1">
              <h1 className="text-[15px] sm:text-[17px] font-extrabold tracking-[0.04em] uppercase text-white leading-tight truncate">
                {t.title}
              </h1>
              <p className="mt-0.5 text-[11.5px] sm:text-[13px] text-[#7c7f8c] leading-[1.45]">
                {t.subtitlePrefix}
                <span className="inline-block px-1.5 py-[1px] rounded-[5px] bg-white/[0.07] border border-white/[0.08] text-[#c8cbd6] font-medium leading-tight">
                  {t.subtitleHighlight}
                </span>
                {t.subtitleSuffix}
              </p>
            </div>
          </div>

          {/* EN / ID Language Switcher */}
          <div
            className="inline-flex items-center rounded-full bg-[#171820] border border-white/[0.08] p-1 shrink-0"
            role="group"
            aria-label="Language selector"
          >
            <button
              type="button"
              onClick={() => setLang('en')}
              aria-pressed={lang === 'en'}
              className={`min-h-[34px] min-w-[36px] sm:min-w-[40px] px-2 sm:px-2.5 rounded-full text-[11px] sm:text-xs font-bold tracking-wider transition-colors cursor-pointer whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-400 ${
                lang === 'en'
                  ? 'bg-[#262833] text-white shadow-sm'
                  : 'text-[#6c6f7c] hover:text-zinc-300'
              }`}
            >
              EN
            </button>
            <button
              type="button"
              onClick={() => setLang('id')}
              aria-pressed={lang === 'id'}
              className={`min-h-[34px] min-w-[36px] sm:min-w-[40px] px-2 sm:px-2.5 rounded-full text-[11px] sm:text-xs font-bold tracking-wider transition-colors cursor-pointer whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-400 ${
                lang === 'id'
                  ? 'bg-[#262833] text-white shadow-sm'
                  : 'text-[#6c6f7c] hover:text-zinc-300'
              }`}
            >
              ID
            </button>
          </div>
        </header>

        {/* MENU Section */}
        <section className="mt-5 sm:mt-6" aria-labelledby="menu-heading">
          <h2
            id="menu-heading"
            className="text-[11px] font-semibold tracking-[0.14em] uppercase text-[#8b8e9a] mb-2.5"
          >
            {t.menuLabel}
          </h2>

          <input
            ref={fileInputRef}
            type="file"
            accept="video/mp4,video/quicktime,.mp4,.mov"
            onChange={onFileInputChange}
            className="sr-only"
            aria-label={t.selectVideo}
          />

          {/* SELECT VIDEO Banner Button */}
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            onDragOver={(e) => {
              e.preventDefault();
              setIsDragging(true);
            }}
            onDragLeave={() => setIsDragging(false)}
            onDrop={onDrop}
            className={`relative w-full h-[116px] sm:h-[136px] rounded-[16px] overflow-hidden border-[1.5px] transition-all cursor-pointer group focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-400 ${
              isDragging
                ? 'border-sky-300 ring-2 ring-sky-400/50 scale-[0.995]'
                : 'border-white/85 hover:border-white'
            }`}
          >
            {!bannerFailed ? (
              <img
                src={BANNER_IMG}
                alt=""
                referrerPolicy="no-referrer"
                onError={() => setBannerFailed(true)}
                className="w-full h-full object-cover object-[50%_26%] transition-transform duration-300 group-hover:scale-[1.03]"
              />
            ) : (
              <div className="w-full h-full bg-gradient-to-br from-sky-900/60 via-slate-800 to-indigo-950" />
            )}

            {/* Subtle scrim for WCAG readability across bright clouds */}
            <div
              className="absolute inset-0 bg-gradient-to-t from-black/30 via-black/10 to-black/15 group-hover:bg-black/20 transition-colors"
              aria-hidden="true"
            />

            <div className="absolute inset-0 flex flex-col items-center justify-center px-4">
              {isReading ? (
                <Loader2 className="w-7 h-7 text-white animate-spin drop-shadow" />
              ) : (
                <span className="select-video-title text-[19px] sm:text-[23px] font-extrabold tracking-[0.11em] uppercase select-none whitespace-nowrap">
                  {isDragging ? t.dropHint : loadedVideo ? t.changeVideo : t.selectVideo}
                </span>
              )}
            </div>
          </button>

          {/* Selected Video Metadata / Status Strip (appears only when active) */}
          {(loadedVideo || errorMsg || hintMsg) && (
            <div className="mt-2.5 rounded-xl bg-[#16171d] border border-white/[0.08] px-3.5 py-2.5">
              {loadedVideo && (
                <div className="flex items-start justify-between gap-2.5">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 min-w-0">
                      <FileVideo className="w-3.5 h-3.5 text-sky-300 shrink-0" />
                      <span className="text-xs font-semibold text-white truncate">
                        {loadedVideo.file.name}
                      </span>
                      <span className="text-[11px] font-mono tabular-nums text-[#8d909c] shrink-0">
                        {formatBytes(loadedVideo.file.size)}
                      </span>
                    </div>

                    <div className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-0.5 text-[11px] text-[#9a9da9] font-mono tabular-nums">
                      {loadedVideo.inspect.width > 0 && loadedVideo.inspect.height > 0 && (
                        <span>
                          {loadedVideo.inspect.width}×{loadedVideo.inspect.height}
                        </span>
                      )}
                      {loadedVideo.inspect.avgFps > 0 && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span>{loadedVideo.inspect.avgFps.toFixed(2)} fps</span>
                        </>
                      )}
                      {loadedVideo.inspect.durationSec > 0 && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span>{formatDuration(loadedVideo.inspect.durationSec)}</span>
                        </>
                      )}
                      {loadedVideo.inspect.videoBitrateBps > 0 && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span>{formatBitrate(loadedVideo.inspect.videoBitrateBps)}</span>
                        </>
                      )}
                      <span aria-hidden="true">·</span>
                      <span className="uppercase">{loadedVideo.inspect.hdrMode}</span>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={clearSelectedFile}
                    aria-label={t.clearFile}
                    className="min-h-[36px] min-w-[36px] flex items-center justify-center rounded-lg text-zinc-400 hover:text-white hover:bg-white/[0.07] transition-colors shrink-0 cursor-pointer"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              )}

              {errorMsg && (
                <div className="mt-1.5 flex items-center gap-2 text-xs text-rose-300">
                  <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                  <span>{errorMsg}</span>
                </div>
              )}

              {hintMsg && !errorMsg && (
                <div className="flex items-center gap-2 text-xs text-sky-200">
                  <AlertCircle className="w-4 h-4 shrink-0 text-sky-400" />
                  <span>{hintMsg}</span>
                </div>
              )}

              {patchedVideo && !errorMsg && (
                <div className="mt-2 pt-2 border-t border-white/[0.06] flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-1.5 text-xs text-emerald-300 font-medium">
                    <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
                    <span>{t.patchedReadyLabel}</span>
                    <span className="text-[#8d909c] font-mono tabular-nums">
                      · {patchedVideo.report.tracks} {t.tracksLabel} ·{' '}
                      {formatBytes(patchedVideo.bytes.byteLength)}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setPreviewOpen(true)}
                      className="px-2.5 py-1 rounded-lg bg-white/[0.07] hover:bg-white/[0.12] text-[11px] font-semibold text-white transition-colors cursor-pointer"
                    >
                      {t.previewVideo}
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        triggerDownload(patchedVideo.blobUrl, patchedVideo.fileName)
                      }
                      aria-label={t.previewModal.download}
                      className="p-1.5 rounded-lg bg-white/[0.07] hover:bg-white/[0.12] text-white transition-colors cursor-pointer"
                    >
                      <Download className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Action Buttons Row */}
          <div className="mt-3 grid grid-cols-2 gap-2.5 sm:gap-3">
            <button
              type="button"
              onClick={handlePatchAndSave}
              disabled={isPatching || isReading}
              className="min-h-[48px] sm:min-h-[50px] px-2.5 sm:px-4 rounded-[12px] bg-[#181920] hover:bg-[#20222c] active:scale-[0.99] disabled:opacity-60 border border-white/[0.08] flex items-center justify-center gap-1.5 sm:gap-2 text-[10.5px] sm:text-[13px] font-bold tracking-[0.04em] uppercase text-white transition-all cursor-pointer whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-400"
            >
              {isPatching && <Loader2 className="w-3.5 h-3.5 animate-spin shrink-0" />}
              <span className="truncate">{isPatching ? t.patching : t.patchAndSave}</span>
            </button>

            <button
              type="button"
              onClick={handleOpenInNewTab}
              className="min-h-[48px] sm:min-h-[50px] px-2.5 sm:px-4 rounded-[12px] bg-[#181920] hover:bg-[#20222c] active:scale-[0.99] border border-white/[0.08] flex items-center justify-center gap-1.5 sm:gap-2 text-[10.5px] sm:text-[13px] font-bold tracking-[0.04em] uppercase text-white transition-all cursor-pointer whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-400"
            >
              <ExternalLink className="w-3.5 h-3.5 sm:w-4 sm:h-4 shrink-0 text-white" />
              <span className="truncate">{t.openInNewTab}</span>
            </button>
          </div>
        </section>

        {/* FOLLOW / COMMUNITY Section */}
        <section className="mt-5 sm:mt-6" aria-labelledby="community-heading">
          <h2
            id="community-heading"
            className="text-[11px] font-semibold tracking-[0.14em] uppercase text-[#8b8e9a] mb-2.5"
          >
            {t.followLabel}
          </h2>

          <div className="grid grid-cols-2 gap-2.5 sm:gap-3">
            <a
              href="https://www.tiktok.com/@zero.sparky"
              target="_blank"
              rel="noopener noreferrer"
              className="min-h-[60px] px-3 sm:px-4 py-3 rounded-[12px] bg-[#16171d] hover:bg-[#1d1f28] border border-white/[0.07] flex items-center gap-2.5 sm:gap-3 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-400"
            >
              <TikTokIcon className="w-5 h-5 text-white shrink-0" />
              <div className="min-w-0">
                <div className="text-[12.5px] sm:text-[13px] font-bold text-white leading-tight">
                  {t.tiktokLabel}
                </div>
                <div className="mt-0.5 text-[11px] sm:text-[11.5px] text-[#7c7f8c] truncate">
                  {t.tiktokHandle}
                </div>
              </div>
            </a>

            <a
              href="https://t.me/zero_sparky"
              target="_blank"
              rel="noopener noreferrer"
              className="min-h-[60px] px-3 sm:px-4 py-3 rounded-[12px] bg-[#16171d] hover:bg-[#1d1f28] border border-white/[0.07] flex items-center gap-2.5 sm:gap-3 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-400"
            >
              <TelegramIcon className="w-5 h-5 shrink-0" />
              <div className="min-w-0">
                <div className="text-[12.5px] sm:text-[13px] font-bold text-white leading-tight">
                  {t.telegramLabel}
                </div>
                <div className="mt-0.5 text-[11px] sm:text-[11.5px] text-[#7c7f8c] truncate">
                  {t.telegramHandle}
                </div>
              </div>
            </a>
          </div>
        </section>

        {/* TUTORIAL Section */}
        <section className="mt-5 sm:mt-6" aria-labelledby="tutorial-heading">
          <h2
            id="tutorial-heading"
            className="text-[11px] font-semibold tracking-[0.14em] uppercase text-[#8b8e9a] mb-2.5"
          >
            {t.tutorialLabel}
          </h2>

          <button
            type="button"
            onClick={() => setTutorialOpen(true)}
            className="w-full min-h-[52px] px-4 py-3 rounded-[12px] bg-[#16171d] hover:bg-[#1d1f28] active:scale-[0.995] border border-white/[0.07] flex items-center gap-3 text-left transition-all cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-400"
          >
            <Play className="w-3.5 h-3.5 text-white fill-white shrink-0" />
            <span className="text-[13px] sm:text-sm font-bold text-white">
              {t.tutorialButton}
            </span>
          </button>
        </section>

        {/* Footer */}
        <footer className="mt-5 sm:mt-6 pt-4 border-t border-white/[0.06] text-center">
          <p className="text-[10px] sm:text-[11px] font-medium tracking-[0.18em] uppercase text-[#757885]">
            {t.footerText}
          </p>
        </footer>
      </main>

      <TutorialModal
        open={tutorialOpen}
        onClose={() => setTutorialOpen(false)}
        copy={t.tutorialModal}
      />

      <VideoPreviewModal
        open={previewOpen}
        onClose={() => setPreviewOpen(false)}
        videoUrl={activePreviewUrl}
        fileName={activePreviewName}
        copy={t.previewModal}
      />
    </div>
  );
}
